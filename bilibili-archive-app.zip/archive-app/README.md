# B站旧档 · 档案库

一个纯静态的档案库网页应用，自动读取 GitHub 仓库中的档案文件夹并展示。

## 功能特性

- 📂 **自动读取**：动态读取 GitHub 仓库根目录，每个文件夹自动作为一个档案展示
- 🔍 **搜索过滤**：支持按档案名称搜索
- 📝 **文字档案**：支持 JSON 格式（带语法高亮），解析失败自动降级为纯文本
- 🖼️ **图片浏览**：网格展示 + 全屏查看器 + 左右翻页 + 键盘导航
- 🎬 **视频播放**：原生 HTML5 播放器，支持下载
- 📱 **响应式**：完美适配桌面和手机
- 🚀 **零后端**：纯 HTML + JS，可直接部署到 GitHub Pages

## 文件结构

```
archive-app/
├── index.html              # 主入口
├── css/
│   └── style.css           # 样式文件
└── js/
    ├── config.jsx          # 配置文件（仓库地址等）
    ├── App.jsx             # 主应用逻辑
    └── components/
        ├── ArchiveList.jsx    # 档案列表
        ├── ArchiveDetail.jsx  # 档案详情
        └── ImageViewer.jsx    # 图片查看器
```

## 部署到 GitHub Pages

1. 修改 `js/config.jsx` 中的仓库配置
2. 将所有文件推送到 GitHub 仓库
3. 在仓库 Settings → Pages 中选择分支和目录
4. 等待部署完成即可访问

## 档案格式

每个文件夹是一个档案，文件夹名即档案名：

```
档案名字/
├── 图片1.png   （图片，支持 jpg/png/gif/webp 等，多张依次编号）
├── 视频1.mp4   （视频，支持 mp4/webm 等，多个依次编号）
└── 文字.json   （文字内容，JSON 格式；解析失败自动按纯文本显示）
```

## 配置说明

在 `js/config.jsx` 中修改：

```js
repoOwner: "你的GitHub用户名",
repoName: "仓库名",
branch: "main",       // 分支名
```

## 注意事项

- GitHub API 有速率限制（未认证每小时 60 次）
- 仓库需设为公开
- 大文件建议使用 Git LFS
