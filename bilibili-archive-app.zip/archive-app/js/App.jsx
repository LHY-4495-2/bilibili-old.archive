// 主应用组件
function App() {
  const [archives, setArchives] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState(null);
  const [selectedArchive, setSelectedArchive] = React.useState(null);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [viewerIndex, setViewerIndex] = React.useState(-1); // -1 表示未打开
  const [demoMode, setDemoMode] = React.useState(false);

  const { apiBase, rawBase, imageExtensions, videoExtensions, textFileName, imagePrefix, videoPrefix, repoUrl } = window.APP_CONFIG;

  // 加载档案列表
  const loadArchives = React.useCallback(() => {
    setLoading(true);
    setError(null);

    // 使用 GitHub Contents API 获取根目录列表
    fetch(`${apiBase}/contents/`)
      .then((res) => {
        if (res.status === 403) {
          throw new Error("rate_limited");
        }
        if (res.status === 404) {
          throw new Error("not_found");
        }
        if (!res.ok) {
          throw new Error(`http_${res.status}`);
        }
        return res.json();
      })
      .then((data) => {
        if (!Array.isArray(data)) {
          throw new Error("invalid_format");
        }

        // 筛选出文件夹
        const folders = data.filter((item) => item.type === "dir");

        if (folders.length === 0) {
          setArchives([]);
          setLoading(false);
          return;
        }

        // 并行获取每个文件夹的内容
        return Promise.all(
          folders.map((folder) =>
            fetch(`${apiBase}/contents/${encodeURIComponent(folder.name)}`)
              .then((res) => res.json())
              .then((files) => {
                if (!Array.isArray(files)) {
                  return parseArchiveFolder(folder.name, []);
                }
                return parseArchiveFolder(folder.name, files);
              })
              .catch(() => parseArchiveFolder(folder.name, []))
          )
        ).then((parsedArchives) => {
          // 按名称排序
          parsedArchives.sort((a, b) => a.name.localeCompare(b.name, "zh-CN"));
          setArchives(parsedArchives);
          setLoading(false);
        });
      })
      .catch((err) => {
        // API 访问失败时，使用演示数据
        const demoArchives = getDemoArchives();
        setArchives(demoArchives);
        setDemoMode(true);
        setError(null); // 不显示错误，静默使用演示数据
        setLoading(false);
        console.warn("[档案库] GitHub API 访问失败，已切换到演示模式：", err.message);
      });
  }, [apiBase, parseArchiveFolder]);

  // 解析单个档案文件夹
  const parseArchiveFolder = React.useCallback(
    (folderName, files) => {
      const images = [];
      const videos = [];
      let textFile = null;

      files.forEach((file) => {
        if (file.type !== "file") return;

        const fileName = file.name;
        const lowerName = fileName.toLowerCase();

        // 判断是否为文字文件
        if (fileName === textFileName || lowerName === textFileName.toLowerCase()) {
          textFile = {
            name: fileName,
            url: file.download_url || `${rawBase}/${encodeURIComponent(folderName)}/${encodeURIComponent(fileName)}`,
          };
          return;
        }

        // 判断是否为图片
        const isImage = imageExtensions.some((ext) => lowerName.endsWith(ext));
        if (isImage) {
          images.push({
            name: fileName,
            url: file.download_url || `${rawBase}/${encodeURIComponent(folderName)}/${encodeURIComponent(fileName)}`,
          });
          return;
        }

        // 判断是否为视频
        const isVideo = videoExtensions.some((ext) => lowerName.endsWith(ext));
        if (isVideo) {
          videos.push({
            name: fileName,
            url: file.download_url || `${rawBase}/${encodeURIComponent(folderName)}/${encodeURIComponent(fileName)}`,
          });
          return;
        }
      });

      // 按文件名中的数字排序（图片1, 图片2...）
      const extractNumber = (name) => {
        const match = name.match(/(\d+)/);
        return match ? parseInt(match[1], 10) : 0;
      };

      images.sort((a, b) => {
        const numA = extractNumber(a.name);
        const numB = extractNumber(b.name);
        if (numA !== numB) return numA - numB;
        return a.name.localeCompare(b.name, "zh-CN");
      });

      videos.sort((a, b) => {
        const numA = extractNumber(a.name);
        const numB = extractNumber(b.name);
        if (numA !== numB) return numA - numB;
        return a.name.localeCompare(b.name, "zh-CN");
      });

      // 获取最近更新时间（取文件夹中最新文件的时间，或用文件夹名中的日期）
      const lastUpdated = files.length > 0
        ? files.reduce((latest, f) => {
            if (!f.last_modified) return latest;
            return !latest || f.last_modified > latest ? f.last_modified : latest;
          }, null)
        : null;

      return {
        name: folderName,
        images,
        videos,
        textFile,
        hasText: !!textFile,
        imageCount: images.length,
        videoCount: videos.length,
        lastUpdated,
      };
    },
    [imageExtensions, videoExtensions, textFileName, rawBase]
  );

  // 初始加载
  React.useEffect(() => {
    loadArchives();
  }, [loadArchives]);

  // 查看图片
  const handleViewImage = React.useCallback((index) => {
    setViewerIndex(index);
  }, []);

  const handleCloseViewer = React.useCallback(() => {
    setViewerIndex(-1);
  }, []);

  const handlePrevImage = React.useCallback(() => {
    if (!selectedArchive) return;
    setViewerIndex((prev) =>
      prev <= 0 ? selectedArchive.images.length - 1 : prev - 1
    );
  }, [selectedArchive]);

  const handleNextImage = React.useCallback(() => {
    if (!selectedArchive) return;
    setViewerIndex((prev) =>
      prev >= selectedArchive.images.length - 1 ? 0 : prev + 1
    );
  }, [selectedArchive]);

  // 选择档案
  const handleSelectArchive = React.useCallback((archive) => {
    setSelectedArchive(archive);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  // 返回列表
  const handleBack = React.useCallback(() => {
    setSelectedArchive(null);
    setViewerIndex(-1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  // 点击 logo 返回首页
  const handleBrandClick = React.useCallback(() => {
    setSelectedArchive(null);
    setViewerIndex(-1);
    setSearchQuery("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  return (
    <>
      <nav className="navbar">
        <div className="navbar-inner">
          <div className="brand" onClick={handleBrandClick}>
            <div className="brand-seal">旧</div>
            <div className="brand-text">
              <span className="brand-title">B 站旧档</span>
              <span className="brand-subtitle">Archive Library</span>
            </div>
          </div>
          <div className="nav-right">
            {!selectedArchive && (
              <div className="search-box">
                <svg className="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="11" cy="11" r="8"></circle>
                  <path d="m21 21-4.35-4.35"></path>
                </svg>
                <input
                  type="text"
                  placeholder="搜索档案..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            )}
            <a
              className="repo-link"
              href={repoUrl}
              target="_blank"
              rel="noopener noreferrer"
              title="查看 GitHub 仓库"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
              </svg>
              <span>仓库</span>
            </a>
          </div>
        </div>
      </nav>

      {demoMode && (
        <div style={{
          background: "linear-gradient(90deg, #fef3c7, #fde68a)",
          borderBottom: "1px solid #f59e0b",
          padding: "10px 24px",
          textAlign: "center",
          fontSize: "13px",
          color: "#92400e",
          position: "relative",
          zIndex: 99,
        }}>
          <span style={{ fontWeight: 500 }}>演示模式</span>
          <span style={{ marginLeft: "8px", opacity: 0.85 }}>
            · 当前展示的是示例数据。配置好 GitHub 仓库后将自动加载真实档案。
          </span>
          <span style={{ marginLeft: "12px", fontSize: "12px", opacity: 0.7 }}>
            修改 <code style={{ background: "rgba(0,0,0,0.08)", padding: "2px 6px", borderRadius: "3px" }}>js/config.jsx</code> 中的仓库地址
          </span>
        </div>
      )}

      <main className="main-content">
        {selectedArchive ? (
          <ArchiveDetail
            archive={selectedArchive}
            onBack={handleBack}
            onViewImage={handleViewImage}
          />
        ) : (
          <ArchiveList
            archives={archives}
            loading={loading}
            error={error}
            onRetry={loadArchives}
            onSelect={handleSelectArchive}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
          />
        )}
      </main>

      {/* 图片查看器 */}
      {viewerIndex >= 0 && selectedArchive && selectedArchive.images.length > 0 && (
        <ImageViewer
          images={selectedArchive.images}
          currentIndex={viewerIndex}
          onClose={handleCloseViewer}
          onPrev={handlePrevImage}
          onNext={handleNextImage}
        />
      )}
    </>
  );
}

// ========== 演示数据 ==========
// 当 GitHub API 无法访问时，使用这些示例数据展示界面效果
function getDemoArchives() {
  const img1 = "/spark/app/app_17dxd82kprx/runtime/api/v1/storage/object/bucket_aadkup45thqbs_static/static%2Faadkupwwgiceu_ve_miaoda";
  const img2 = "/spark/app/app_17dxd82kprx/runtime/api/v1/storage/object/bucket_aadkup45thqbs_static/static%2Faadkup2zm6yvu_ve_miaoda";
  const img3 = "/spark/app/app_17dxd82kprx/runtime/api/v1/storage/object/bucket_aadkup45thqbs_static/static%2Faadkupzkvzkls_ve_miaoda";

  return [
    {
      name: "2009年初创时期",
      images: [
        { name: "图片1.png", url: img1 },
        { name: "图片2.png", url: img2 },
      ],
      videos: [
        { name: "视频1.mp4", url: "https://www.w3schools.com/html/mov_bbb.mp4" },
      ],
      textFile: {
        name: "文字.json",
        url: "data:application/json;charset=utf-8," + encodeURIComponent(
          JSON.stringify({
            标题: "B站初创时期档案",
            时间: "2009年6月 - 2010年",
            简介: "B站最初由徐逸（⑨bishi）于2009年6月26日创建，最初名为Mikufans，是一个以ACG内容为主的视频分享网站。早期用户群体主要来自ACG圈子，以搬运日本Niconico动画的内容为主。",
            关键事件: [
              "2009年6月26日：Mikufans建站",
              "2010年1月：更名为bilibili",
              "2010年：开放用户投稿功能"
            ],
            备注: "此为演示数据，实际内容请以仓库为准。"
          }, null, 2)
        ),
      },
      hasText: true,
      imageCount: 2,
      videoCount: 1,
      lastUpdated: "2024-01-15T10:30:00Z",
    },
    {
      name: "2012年拜年祭",
      images: [
        { name: "图片1.png", url: img3 },
        { name: "图片2.png", url: img1 },
        { name: "图片3.png", url: img2 },
      ],
      videos: [],
      textFile: {
        name: "文字.json",
        url: "data:text/plain;charset=utf-8," + encodeURIComponent(
          "2012年B站拜年祭\n\n这是B站历史上第一届拜年祭，于2012年龙年春节期间举办。\n\n当时的参与UP主数量不多，但开创了一个重要的传统。\n拜年祭后来逐渐发展成为B站每年最重要的活动之一。\n\n—— 档案记录"
        ),
      },
      hasText: true,
      imageCount: 3,
      videoCount: 0,
      lastUpdated: "2024-02-20T08:00:00Z",
    },
    {
      name: "早期UP主档案",
      images: [
        { name: "图片1.png", url: img2 },
      ],
      videos: [
        { name: "视频1.mp4", url: "https://www.w3schools.com/html/movie.mp4" },
      ],
      textFile: null,
      hasText: false,
      imageCount: 1,
      videoCount: 1,
      lastUpdated: "2024-03-10T14:20:00Z",
    },
    {
      name: "旧版界面设计",
      images: [
        { name: "图片1.png", url: img1 },
        { name: "图片2.png", url: img3 },
        { name: "图片3.png", url: img2 },
        { name: "图片4.png", url: img1 },
      ],
      videos: [],
      textFile: {
        name: "文字.json",
        url: "data:application/json;charset=utf-8," + encodeURIComponent(
          JSON.stringify({
            版本: "v2.0",
            年代: "2013-2015",
            设计特点: [
              "粉色主色调",
              "三栏布局",
              "顶部分区导航",
              "右侧排行榜"
            ],
            说明: "这一时期的界面设计深受早期ACG文化影响，整体风格更加活泼。"
          }, null, 2)
        ),
      },
      hasText: true,
      imageCount: 4,
      videoCount: 0,
      lastUpdated: "2024-04-05T09:45:00Z",
    },
    {
      name: "大会员制度变迁",
      images: [],
      videos: [],
      textFile: {
        name: "文字.json",
        url: "data:application/json;charset=utf-8," + encodeURIComponent(
          JSON.stringify({
            标题: "大会员制度发展历程",
            时间线: [
              { 时间: "2016年", 事件: "推出大会员制度" },
              { 时间: "2017年", 事件: "年度大会员上线" },
              { 时间: "2018年", 事件: "扩大权益范围" },
              { 时间: "2020年", 事件: "大会员数量破千万" }
            ]
          }, null, 2)
        ),
      },
      hasText: true,
      imageCount: 0,
      videoCount: 0,
      lastUpdated: "2024-05-12T16:00:00Z",
    },
  ];
}

// 渲染应用
const root = ReactDOM.createRoot(document.getElementById("app"));
root.render(<App />);
