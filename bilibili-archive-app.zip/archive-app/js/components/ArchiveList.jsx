// 档案列表组件
function ArchiveList({ archives, loading, error, onRetry, onSelect, searchQuery, onSearchChange }) {
  const filteredArchives = archives.filter((a) =>
    a.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalImages = archives.reduce((sum, a) => sum + a.imageCount, 0);
  const totalVideos = archives.reduce((sum, a) => sum + a.videoCount, 0);

  return (
    <div>
      <section className="hero">
        <div className="hero-eyebrow">Archive Collection</div>
        <h1 className="hero-title">旧档珍藏</h1>
        <p className="hero-desc">
          一份关于过往的数字化档案库，记录那些值得被留存的时光与故事。
          所有档案均来自开源仓库，持续更新中。
        </p>
        <div className="hero-stats">
          <div className="hero-stat">
            <div className="hero-stat-num">{archives.length}</div>
            <div className="hero-stat-label">档案总数</div>
          </div>
          <div className="hero-stat">
            <div className="hero-stat-num">{totalImages}</div>
            <div className="hero-stat-label">图片资料</div>
          </div>
          <div className="hero-stat">
            <div className="hero-stat-num">{totalVideos}</div>
            <div className="hero-stat-label">视频资料</div>
          </div>
        </div>
      </section>

      <div className="section-header">
        <h2 className="section-title">全部档案</h2>
        <div style={{ display: "flex", gap: "8px" }}>
          <div className="search-box">
            <svg className="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="8"></circle>
              <path d="m21 21-4.35-4.35"></path>
            </svg>
            <input
              type="text"
              placeholder="搜索档案..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
            />
          </div>
        </div>
      </div>

      {loading && (
        <div className="loading-state">
          <div className="loading-spinner"></div>
          <p className="loading-text">正在读取档案库...</p>
        </div>
      )}

      {error && (
        <div className="error-state">
          <svg className="error-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="12"></line>
            <line x1="12" y1="16" x2="12.01" y2="16"></line>
          </svg>
          <h3 className="error-title">读取失败</h3>
          <p className="error-desc">{error}</p>
          <button className="error-btn" onClick={onRetry}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 12a9 9 0 1 1-3-6.7L21 8"></path>
              <polyline points="21 3 21 8 16 8"></polyline>
            </svg>
            重新加载
          </button>
        </div>
      )}

      {!loading && !error && filteredArchives.length === 0 && (
        <div className="empty-state">
          <svg className="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <rect x="3" y="3" width="18" height="18" rx="2"></rect>
            <path d="M3 9h18"></path>
            <path d="M9 21V9"></path>
          </svg>
          <h3 className="empty-title">
            {searchQuery ? "未找到匹配的档案" : "暂无档案"}
          </h3>
          <p className="empty-desc">
            {searchQuery ? "试试其他关键词" : "向仓库中添加档案文件夹即可在此显示"}
          </p>
        </div>
      )}

      {!loading && !error && filteredArchives.length > 0 && (
        <div className="archive-grid">
          {filteredArchives.map((archive) => (
            <ArchiveCard
              key={archive.name}
              archive={archive}
              onClick={() => onSelect(archive)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function ArchiveCard({ archive, onClick }) {
  const hasText = archive.hasText;
  const hasImages = archive.imageCount > 0;
  const hasVideos = archive.videoCount > 0;

  // 取前3张图作为预览
  const previewImages = archive.images.slice(0, 3);
  const placeholderCount = Math.max(0, 3 - previewImages.length);

  return (
    <div className="archive-card" onClick={onClick}>
      <div className="archive-card-seal">
        档案
      </div>
      <h3 className="archive-card-title">{archive.name}</h3>

      <div className="archive-card-meta">
        {hasText && (
          <span className="meta-tag">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <line x1="16" y1="13" x2="8" y2="13"></line>
              <line x1="16" y1="17" x2="8" y2="17"></line>
            </svg>
            文字
          </span>
        )}
        {hasImages && (
          <span className="meta-tag">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="18" height="18" rx="2"></rect>
              <circle cx="8.5" cy="8.5" r="1.5"></circle>
              <polyline points="21 15 16 10 5 21"></polyline>
            </svg>
            {archive.imageCount} 张
          </span>
        )}
        {hasVideos && (
          <span className="meta-tag">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polygon points="23 7 16 12 23 17 23 7"></polygon>
              <rect x="1" y="5" width="15" height="14" rx="2"></rect>
            </svg>
            {archive.videoCount} 个
          </span>
        )}
      </div>

      {previewImages.length > 0 && (
        <div className="archive-card-preview">
          {previewImages.map((img, idx) => (
            <div key={idx} className="preview-thumb">
              <img src={img.url} alt={img.name} loading="lazy" />
            </div>
          ))}
          {Array.from({ length: placeholderCount }).map((_, idx) => (
            <div key={`ph-${idx}`} className="preview-thumb placeholder"></div>
          ))}
        </div>
      )}

      <div className="archive-card-footer">
        <span className="archive-card-date">
          {archive.lastUpdated ? archive.lastUpdated.slice(0, 10) : "—"}
        </span>
        <svg
          className="archive-card-arrow"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
        >
          <line x1="5" y1="12" x2="19" y2="12"></line>
          <polyline points="12 5 19 12 12 19"></polyline>
        </svg>
      </div>
    </div>
  );
}

window.ArchiveList = ArchiveList;
