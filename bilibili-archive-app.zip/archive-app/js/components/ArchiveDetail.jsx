// 档案详情组件
function ArchiveDetail({ archive, onBack, onViewImage }) {
  const [textContent, setTextContent] = React.useState(null);
  const [textLoading, setTextLoading] = React.useState(false);
  const [textError, setTextError] = React.useState(null);
  const [isJson, setIsJson] = React.useState(false);

  const { textFile, images, videos } = archive;

  React.useEffect(() => {
    if (!textFile) return;

    setTextLoading(true);
    setTextError(null);

    fetch(textFile.url)
      .then((res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return res.text();
      })
      .then((text) => {
        // 尝试解析为 JSON
        try {
          const parsed = JSON.parse(text);
          setTextContent(parsed);
          setIsJson(true);
        } catch (e) {
          // 解析失败按纯文本显示
          setTextContent(text);
          setIsJson(false);
        }
        setTextLoading(false);
      })
      .catch((err) => {
        setTextError(err.message);
        setTextLoading(false);
      });
  }, [textFile?.url]);

  return (
    <div>
      <button className="detail-back" onClick={onBack}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <line x1="19" y1="12" x2="5" y2="12"></line>
          <polyline points="12 19 5 12 12 5"></polyline>
        </svg>
        返回档案列表
      </button>

      <header className="detail-header">
        <h1 className="detail-title">{archive.name}</h1>
        <div className="detail-meta">
          <div className="detail-meta-item">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="4" width="18" height="18" rx="2"></rect>
              <line x1="16" y1="2" x2="16" y2="6"></line>
              <line x1="8" y1="2" x2="8" y2="6"></line>
              <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
            {archive.lastUpdated ? `更新于 ${archive.lastUpdated.slice(0, 10)}` : "未知日期"}
          </div>
          {archive.hasText && (
            <div className="detail-meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
              </svg>
              含文字档案
            </div>
          )}
          {images.length > 0 && (
            <div className="detail-meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="3" width="18" height="18" rx="2"></rect>
                <circle cx="8.5" cy="8.5" r="1.5"></circle>
                <polyline points="21 15 16 10 5 21"></polyline>
              </svg>
              {images.length} 张图片
            </div>
          )}
          {videos.length > 0 && (
            <div className="detail-meta-item">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polygon points="23 7 16 12 23 17 23 7"></polygon>
                <rect x="1" y="5" width="15" height="14" rx="2"></rect>
              </svg>
              {videos.length} 个视频
            </div>
          )}
        </div>
      </header>

      {/* 文字内容 */}
      {textFile && (
        <section className="detail-section">
          <h2 className="detail-section-title">
            <svg className="detail-section-title-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 20h9"></path>
              <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path>
            </svg>
            文字档案
          </h2>
          {textLoading && (
            <div className="loading-state" style={{ padding: "40px 20px" }}>
              <div className="loading-spinner" style={{ width: "28px", height: "28px" }}></div>
              <p className="loading-text">正在读取文字内容...</p>
            </div>
          )}
          {textError && (
            <div className="text-content">
              <p style={{ color: "var(--vermilion)", textAlign: "center" }}>
                读取失败：{textError}
              </p>
            </div>
          )}
          {!textLoading && !textError && textContent !== null && (
            <div className="text-content">
              {isJson ? (
                <pre className="text-content-json">
                  <code dangerouslySetInnerHTML={{ __html: formatJsonWithColor(textContent) }}></code>
                </pre>
              ) : (
                <p className="text-content-plain">{textContent}</p>
              )}
            </div>
          )}
        </section>
      )}

      {/* 图片 */}
      {images.length > 0 && (
        <section className="detail-section">
          <h2 className="detail-section-title">
            <svg className="detail-section-title-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="18" height="18" rx="2"></rect>
              <circle cx="8.5" cy="8.5" r="1.5"></circle>
              <polyline points="21 15 16 10 5 21"></polyline>
            </svg>
            图片资料
            <span style={{ fontSize: "14px", color: "var(--ink-3)", fontWeight: "400", marginLeft: "8px" }}>
              共 {images.length} 张 · 点击查看大图
            </span>
          </h2>
          <div className="image-grid">
            {images.map((img, idx) => (
              <div
                key={img.name}
                className="image-item"
                onClick={() => onViewImage(idx)}
              >
                <img src={img.url} alt={img.name} loading="lazy" />
                <div className="image-item-overlay">
                  <span className="image-item-name">{img.name}</span>
                  <a
                    className="image-item-download"
                    href={img.url}
                    download={img.name}
                    onClick={(e) => e.stopPropagation()}
                    title="下载图片"
                  >
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                      <polyline points="7 10 12 15 17 10"></polyline>
                      <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 视频 */}
      {videos.length > 0 && (
        <section className="detail-section">
          <h2 className="detail-section-title">
            <svg className="detail-section-title-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polygon points="23 7 16 12 23 17 23 7"></polygon>
              <rect x="1" y="5" width="15" height="14" rx="2"></rect>
            </svg>
            视频资料
            <span style={{ fontSize: "14px", color: "var(--ink-3)", fontWeight: "400", marginLeft: "8px" }}>
              共 {videos.length} 个
            </span>
          </h2>
          <div className="video-list">
            {videos.map((video) => (
              <div key={video.name} className="video-item">
                <div className="video-player">
                  <video controls preload="metadata" poster="">
                    <source src={video.url} type="video/mp4" />
                    您的浏览器不支持视频播放。
                  </video>
                </div>
                <div className="video-item-info">
                  <span className="video-item-name">{video.name}</span>
                  <div className="video-item-actions">
                    <a
                      className="btn-download"
                      href={video.url}
                      download={video.name}
                    >
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="7 10 12 15 17 10"></polyline>
                        <line x1="12" y1="15" x2="12" y2="3"></line>
                      </svg>
                      下载视频
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

// 将 JSON 对象格式化为带语法高亮的 HTML
function formatJsonWithColor(obj) {
  const jsonStr = JSON.stringify(obj, null, 2);
  return jsonStr.replace(
    /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
    function (match) {
      let cls = "json-number";
      if (/^"/.test(match)) {
        if (/:$/.test(match)) {
          cls = "json-key";
        } else {
          cls = "json-string";
        }
      } else if (/true|false/.test(match)) {
        cls = "json-boolean";
      } else if (/null/.test(match)) {
        cls = "json-null";
      }
      return '<span class="' + cls + '">' + match + "</span>";
    }
  );
}

window.ArchiveDetail = ArchiveDetail;
