// 图片查看器（全屏大图预览）
function ImageViewer({ images, currentIndex, onClose, onPrev, onNext }) {
  const currentImage = images[currentIndex];

  React.useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") onPrev();
      if (e.key === "ArrowRight") onNext();
    };
    window.addEventListener("keydown", handleKeyDown);

    // 禁止背景滚动
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = originalOverflow;
    };
  }, [onClose, onPrev, onNext]);

  const handleOverlayClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div className="viewer-overlay" onClick={handleOverlayClick}>
      <div className="viewer-content">
        <button
          className="viewer-close"
          onClick={onClose}
          aria-label="关闭"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>

        {images.length > 1 && (
          <>
            <button
              className="viewer-nav prev"
              onClick={onPrev}
              aria-label="上一张"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="15 18 9 12 15 6"></polyline>
              </svg>
            </button>
            <button
              className="viewer-nav next"
              onClick={onNext}
              aria-label="下一张"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="9 18 15 12 9 6"></polyline>
              </svg>
            </button>
          </>
        )}

        <img
          className="viewer-img"
          src={currentImage.url}
          alt={currentImage.name}
        />

        <div className="viewer-caption">
          <span>{currentImage.name}</span>
          <span>
            {currentIndex + 1} / {images.length}
          </span>
          <a
            className="viewer-caption-btn"
            href={currentImage.url}
            download={currentImage.name}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="7 10 12 15 17 10"></polyline>
              <line x1="12" y1="15" x2="12" y2="3"></line>
            </svg>
            下载原图
          </a>
        </div>
      </div>
    </div>
  );
}

window.ImageViewer = ImageViewer;
