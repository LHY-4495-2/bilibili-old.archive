// 配置文件 - 可根据实际仓库修改
const APP_CONFIG = {
  // GitHub 仓库信息
  repoOwner: "LHY-4495-2",
  repoName: "bilibili-old.archive",
  branch: "main",

  // 文件名匹配规则
  imageExtensions: [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"],
  videoExtensions: [".mp4", ".webm", ".ogg", ".mov", ".mkv"],
  textFileName: "文字.json",

  // 图片前缀匹配（用于排序）
  imagePrefix: "图片",
  videoPrefix: "视频",

  // GitHub API 基础地址
  get apiBase() {
    return `https://api.github.com/repos/${this.repoOwner}/${this.repoName}`;
  },

  // 原始文件 CDN 地址（直接访问文件内容，避免 API 速率限制）
  get rawBase() {
    return `https://raw.githubusercontent.com/${this.repoOwner}/${this.repoName}/${this.branch}`;
  },

  // 仓库首页
  get repoUrl() {
    return `https://github.com/${this.repoOwner}/${this.repoName}`;
  },
};

window.APP_CONFIG = APP_CONFIG;
